let count = 0;

const messages = [
  "Keep going!",
  "You're doing great!",
  "Nice clicks!",
  "Don't stop now!",
  "Consistency wins!"
];

const counterBtn = 
document.getElementById("counterBtn");
const resetBtn =
document.getElementById("resetBtn");
const popup = 
document.getElementById("popup");

counterBtn.addEventListener("click",
() => {
  count++;
  counterBtn.textContent = count;

  // show message 
  if (count % 10 === 0) {
    showMessage();
  }
});

resetBtn.addEventListener("click", 
  () => {
    count = 0;
    counterBtn.textContent = count;
  });


function showMessage() {
  const randomMsg = 
  messages[Math.floor(Math.random() * 
    messages.length)];
    popup.textContent = randomMsg;
    popup.classList.add("show");
    
    setTimeout(() => {
      popup.classList.remove("show");
     }, 1500);
    }